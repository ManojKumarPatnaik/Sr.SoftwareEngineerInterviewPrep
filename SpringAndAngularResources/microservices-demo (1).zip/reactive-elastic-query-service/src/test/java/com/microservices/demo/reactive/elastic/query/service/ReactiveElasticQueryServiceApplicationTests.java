package com.microservices.demo.reactive.elastic.query.service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class ReactiveElasticQueryServiceApplicationTests {

    @Test
    public void contextLoads() {
    }

}
