import { Component, ViewChild, ElementRef, Input, ViewChildren, QueryList, ContentChild } from '@angular/core';
import {comp2} from "./comp2"
import {Observable,timer } from 'rxjs';

@Component({
  selector: 'app-root',
  templateUrl: './comp1.html',
  styleUrls: ['./app.component.css']
})
export class comp1 {
  @ViewChild('div1',{ static: false }) divref: ElementRef;
  @ViewChild(comp2,{ static: false }) tref1: comp2;
  @ViewChildren(comp2) myComponents: QueryList<comp2>;

  
  ngAfterViewInit(){
    //alert(this.divref.nativeElement.innerHTML);
    //this.tref1.Click();
    //alert(this.myComponents.length);
  }
  ngOnInit() {
    // alert(this.divref.nativeElement.innerHTML);
   }
}

