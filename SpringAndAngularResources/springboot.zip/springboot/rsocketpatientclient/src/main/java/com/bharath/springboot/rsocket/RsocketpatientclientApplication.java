package com.bharath.springboot.rsocket;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RsocketpatientclientApplication {

	public static void main(String[] args) {
		SpringApplication.run(RsocketpatientclientApplication.class, args);
	}

}
