package com.microservices.demo.elastic.model.index;

public interface IndexModel {
    String getId();
}
